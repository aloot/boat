drop table volymtyp;
drop table trucktyp;
drop table empstatus;
drop table kktyp;
drop table kajtyp;
drop table empschema;
drop table truckstatus;